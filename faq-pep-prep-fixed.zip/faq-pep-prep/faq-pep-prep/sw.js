const CACHE_NAME = "prep-pep-pwa-cache-v1";
const PRECACHE_URLS = [
  "/",
  "./index.html",
  "/app.js",
  "/manifest.json",
  "./data/presentation.json",
  "./data/faq.json",
  "./assets/img/hero.png",
  "./assets/audio/presentation.mp3",
  // cache all audio description placeholders for FAQs (PrEP and PEP)
  "./assets/audio/prep1.mp3",
  "./assets/audio/prep2.mp3",
  "./assets/audio/prep3.mp3",
  "./assets/audio/prep4.mp3",
  "./assets/audio/prep5.mp3",
  "./assets/audio/prep6.mp3",
  "./assets/audio/prep7.mp3",
  "./assets/audio/prep8.mp3",
  "./assets/audio/prep9.mp3",
  "./assets/audio/prep10.mp3",
  "./assets/audio/prep11.mp3",
  "./assets/audio/prep12.mp3",
  "./assets/audio/prep13.mp3",
  "./assets/audio/prep14.mp3",
  "./assets/audio/prep15.mp3",
  "./assets/audio/prep16.mp3",
  "./assets/audio/prep17.mp3",
  "./assets/audio/prep18.mp3",
  "./assets/audio/prep19.mp3",
  "./assets/audio/prep20.mp3",
  "./assets/audio/prep21.mp3",
  "./assets/audio/prep22.mp3",
  "./assets/audio/prep23.mp3",
  "./assets/audio/prep24.mp3",
  "./assets/audio/prep25.mp3",
  "./assets/audio/prep26.mp3",
  "./assets/audio/prep27.mp3",
  "./assets/audio/prep28.mp3",
  "./assets/audio/prep29.mp3",
  "./assets/audio/prep30.mp3",
  "./assets/audio/prep31.mp3",
  "./assets/audio/prep32.mp3",
  "./assets/audio/prep33.mp3",
  "./assets/audio/prep34.mp3",
  "./assets/audio/prep35.mp3",
  "./assets/audio/prep36.mp3",
  // external libs for offline once cached
  "https://unpkg.com/react@17/umd/react.development.js",
  "https://unpkg.com/react-dom@17/umd/react-dom.development.js",
  "https://unpkg.com/react-router-dom/umd/react-router-dom.min.js",
  "https://unpkg.com/howler/dist/howler.min.js",
  "https://cdn.tailwindcss.com"
];

self.addEventListener('install', event => {
  event.waitUntil(
    caches.open(CACHE_NAME).then(cache => cache.addAll(PRECACHE_URLS))
  );
});

self.addEventListener('activate', event => {
  event.waitUntil(
    caches.keys().then(keys => Promise.all(keys.map(key => {
      if (key !== CACHE_NAME) return caches.delete(key);
    })))
  );
});

self.addEventListener('fetch', event => {
  const requestUrl = new URL(event.request.url);
  if (PRECACHE_URLS.includes(requestUrl.pathname) || PRECACHE_URLS.includes(event.request.url)) {
    event.respondWith(
      caches.match(event.request).then(response => {
        return response || fetch(event.request).then(networkResponse => {
          return caches.open(CACHE_NAME).then(cache => {
            cache.put(event.request, networkResponse.clone());
            return networkResponse;
          });
        });
      })
    );
  } else {
    event.respondWith(
      fetch(event.request).catch(() => caches.match(event.request))
    );
  }
});
